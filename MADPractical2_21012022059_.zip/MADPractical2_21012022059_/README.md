# MADPractical2_21012022059_
prac2
![Pr2_1](https://user-images.githubusercontent.com/80378007/187128019-1bee8c5e-ba2d-46fa-8e98-b7d842146f01.png)
![screen](https://user-images.githubusercontent.com/80378007/187128022-5f2ece59-40f3-4fd7-871f-ca7c1c8ae9dd.png)
![main](https://user-images.githubusercontent.com/80378007/187128024-12bccda6-f748-44b3-a4a5-4bfdbdd2b661.png)
